# Storage CLI
The Storage CLI.... 

### Functions
##### Loginaws
Connecting to servers with a 
username provided to them by the server
* Parameters:
  * AWS access key ID
  * AWS secret key


##### ListObjects
ListObjects lists all objects in the available buckets by bucket name
* Parameters:
  * --bucketname (Optional)
    * Lists the objects for the specified bucket name if that bucket exists

##### PutObject
Upload file to the storage with file path 
* Parameters:
  * --filepath
    * Location of the file 


##### DeleteObject
Delete file to the storage with file path 
* Parameters:git
  * --filepath
    * Location of the file 


